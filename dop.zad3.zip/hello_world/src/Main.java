public class Main {
    public static void main(String[] args) {
        char c1= 'A';
        System.out.println(c1);
        c1= 'A' + 1 ;
        System.out.println(c1);





    }
}