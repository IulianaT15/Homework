public class Main {
    public static void main(String[] args) {
        int i= 20;
        double d= 12.5;
        System.out.println(i*d);



    }
}